# Nostr Poll Bot

A Node.js-based bot that creates and manages real-time polls on the Nostr network.

## Features

- Publish polls with yes/no or custom options.
- Listen for replies (votes) from users.
- One vote per public key is counted.
- Updates poll results live as replies to the original event.

## Requirements

- Node.js v18 or newer.
- Internet connection to reach Nostr relays.

## Setup

1. Install dependencies:

```
npm install
```

2. Run the bot:

```
npm start
```

3. Follow prompts to:

- Provide or generate a private key.
- Create the poll.
- Specify duration (or set 0 to run indefinitely).

## How to Vote

Reply to the poll post using a Nostr client and write your vote (e.g., `Yes` or `No`). The bot will count it once per public key.

## Notes

- Uses the following relays:
  - `wss://relay.damus.io`
  - `wss://nos.lol`
  - `wss://relay.nostr.band`