// poll-bot-with-timer.mjs
import readline from 'readline';
import { relayInit, getEventHash, getSignature, generatePrivateKey, getPublicKey, validateEvent, nip19 } from 'nostr-tools';
import 'websocket-polyfill';

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function prompt(question) {
  return new Promise(resolve => rl.question(question, resolve));
}

const RELAYS = [
  "wss://relay.damus.io",
  "wss://nos.lol",
  "wss://relay.nostr.band"
];

function generateOptionTags(options) {
  return options.map(opt => ["option", Buffer.from(opt).toString('hex'), opt]);
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function connectRelays() {
  const relayConnections = RELAYS.map(async url => {
    const relay = relayInit(url);
    await relay.connect();
    return relay;
  });
  return Promise.all(relayConnections);
}

function listenForVotes(relays, pollId, options, pubkey, updateResults) {
  const votes = new Map();

  relays.forEach(relay => {
    const sub = relay.sub([{ kinds: [1], "#e": [pollId] }]);

    sub.on("event", event => {
      const content = event.content.trim().toLowerCase();
      const voterPubKey = event.pubkey;
      const vote = options.find(opt => opt.toLowerCase() === content);

      if (vote && !votes.has(voterPubKey)) {
        votes.set(voterPubKey, vote);
        updateResults(Object.fromEntries([...votes.entries()].map(([k, v]) => [v, [...votes.values()].filter(x => x === v).length])));
      }
    });
  });
}

async function main() {
  let priv = await prompt("Enter your private key (hex or nsec; leave blank to generate a new one): ");
  if (!priv) {
    priv = generatePrivateKey();
    console.log("Generated new private key (hex):", priv);
    console.log("NSEC (bech32):", nip19.nsecEncode(priv));
  } else if (priv.startsWith("nsec")) {
    priv = nip19.decode(priv).data;
  }

  const pub = getPublicKey(priv);
  console.log("Public key (npub):", nip19.npubEncode(pub));

  const question = await prompt("Enter poll question: ");
  const isYesNo = (await prompt("Is this a yes/no poll? (y/n): ")).toLowerCase() === 'y';
  const options = isYesNo ? ["Yes", "No"] : (await prompt("Enter comma-separated options: ")).split(",").map(x => x.trim());
  const durationMin = parseInt(await prompt("Poll duration in minutes (0 for no time limit): "), 10);

  const created_at = Math.floor(Date.now() / 1000);
  const tags = [
    ...generateOptionTags(options),
    ["polltype", "singlechoice"],
    ...RELAYS.map(url => ["relay", url])
  ];

  const event = {
    kind: 1068,
    created_at,
    tags,
    content: question,
    pubkey: pub,
  };
  event.id = getEventHash(event);
  event.sig = getSignature(event, priv);

  console.log("Created poll event:", JSON.stringify(event, null, 2));
  const relays = await connectRelays();

  await Promise.all(relays.map(relay => relay.publish(event).then(() => {
    console.log(`✅ Published to ${relay.url}`);
  })));

  console.log("✅ Poll published!");
  console.log("📡 Listening indefinitely for votes... (press Ctrl+C to exit)");

  const results = {};
  options.forEach(opt => results[opt] = 0);

  const postResults = async () => {
    const tallyContent = Object.entries(results).map(([k, v]) => `${k}: ${v}`).join('
');
    const resultEvent = {
      kind: 1,
      created_at: Math.floor(Date.now() / 1000),
      tags: [["e", event.id], ...RELAYS.map(url => ["relay", url])],
      content: `📊 Poll update:
${tallyContent}`,
      pubkey: pub,
    };
    resultEvent.id = getEventHash(resultEvent);
    resultEvent.sig = getSignature(resultEvent, priv);

    await Promise.all(relays.map(relay => relay.publish(resultEvent)));
  };

  listenForVotes(relays, event.id, options, pub, newResults => {
    Object.assign(results, newResults);
    postResults();
  });

  rl.close();
}

main().catch(err => {
  console.error("An error occurred:", err);
  rl.close();
});